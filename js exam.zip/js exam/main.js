//1 let num = alert(5 % 2);
// javob 1

//2 let random = alert(Math.random() * 10 + 1 );
// javob 8.521727895089771

//3 alert(Math.floor(12.5));

// 4 function harfsonni(mars) {
//   let harf = mars.length;
//   alert(harf);
// }

// harfsonni("mars it school");

//5 function marsit() {
//   for (let i = 0; i < 10; i++) {
//     console.log("Mars It School");
//   }
// }
// marsit();

//6  let harflar = ["a" ,  "r" , "s" , "i" , "u" , "m"]

//  let ism = harflar[1] + harflar[6] + harflar[4] + harflar[2] +  harflar[4]
//  console.log("amir");

//7 let yosh = prompt("yoshingizni kiritng")

// if (yosh > 18) {
//     console.log ("balogot yoshiga etgansiz");
// } else if (yosh == 18){
//     console.log ("balogat yoshi muborak");
//  }else  {
//     console.log ("balogat yoshiga yetmagansiz");
//  }

//8 const harf = prompt(amir)

//  console.log(harf.reverse(harf));


// 10 let sonlar = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// let juftSonlar = sonlar.filter(son => son % 2 === 0);

// console.log(juftSonlar);